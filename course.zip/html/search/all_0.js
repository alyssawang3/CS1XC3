var searchData=
[
  ['_5fcourse',['_course',['../struct__course.html',1,'']]],
  ['_5fstudent',['_student',['../struct__student.html',1,'']]]
];
