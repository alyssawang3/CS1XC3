/**
 * @file student.h
 * @author Alyssa Wang (wanga121@mcmaster.ca)
 * @brief File containing student structure and function definitions for students
 * @version 0.1
 * @date 2022-04-09
 */

/**
 * @brief Student type that stores information of a student,
 * including the student's name, id, grades, and number of grades
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
