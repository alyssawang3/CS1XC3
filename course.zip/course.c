/**
 * @file course.c
 * @author Alyssa Wang (wanga121@mcmaster.ca)
 * @brief File containing functions that implement a course's information
 * @version 0.1
 * @date 2022-04-09
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

 /**
  * @brief Allocates memory to add a student to a course 
  * 
  * @param course The course that students will enroll in 
  * @param student The student that will be enrolled to the course
  * @return nothing
  */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // If there is one student, then calloc is used to allocate memory for the array
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // If there is more than one student, realloc is used to reallocate the array
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Add the student to the course
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints out all the course information 
 * 
 * @param course The course that will be printed
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Use for loop to print the information of all students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Determines the top student in a course.
 * 
 * @param course The course which the top student is in
 * @return The student with the highest average
 */

Student* top_student(Course* course)
{
  // If there are no students in the course, there is no top student
  if (course->total_students == 0) return NULL;

  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 // Loop through all students and compare the average of each student 
 // in the course to the max average to find the highest average student.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns an array of passing students 
 * 
 * @param course The course from which the number of passing students is being determined 
 * @param total_passing The number of passing students
 * @return Array of students passing the course.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Go through all students to determine which students have an average of 50 or higher
  // Increase the number of passing students based on their average
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocating memory to store all passing students in the array
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // Go through all students and add the students with a passing average (50 or higher) to the array.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}