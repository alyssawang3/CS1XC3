/**
 * @file course.h
 * @author Alyssa Wang (wanga121@mcmaster.ca)
 * @brief File containing course structure and function definitions 
 * @version 0.1
 * @date 2022-04-09
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course type that stores information of a course, 
 * including course name, course code, students, and number of students
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


